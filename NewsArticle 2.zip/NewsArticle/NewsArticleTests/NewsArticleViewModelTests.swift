//
//  NewsArticleViewModelTests.swift
//  NewsArticleTests
//
//  Created by T0118RX on 07/02/25.
//

import XCTest
@testable import NewsArticle

class MockNewsArticleRepository: NewsArticleRepository {
    var mockArticles: [Article]?
    override func fetchArticles(completion: @escaping (Result<[Article], Error>) -> Void) {
        if let articles = mockArticles {
            completion(.success(articles))
        } else {
            completion(.failure(NSError(domain: "TestError", code: 0, userInfo: nil)))
        }
    }
}

final class NewsArticleViewModelTests: XCTestCase {
    
    var viewModel: NewsArticleViewModel!
    var mockRepository: MockNewsArticleRepository!
    
    override func setUp() {
        super.setUp()
        mockRepository = MockNewsArticleRepository()
        viewModel = NewsArticleViewModel(networkService: mockRepository)
    }
    
    override func tearDown() {
        viewModel.articles = []
        viewModel = nil
        mockRepository = nil
        super.tearDown()
    }
    
    func testFetchArticlesSuccess() {
        let mockArticles: [Article] = [
            Article(source: Source(id: "1", name: "Source1"), author: "Author1", title: "Title1", description: "Description1", url: "http://example.com", urlToImage: nil, publishedAt: "2025-01-01", content: "Content1")
        ]
        mockRepository.mockArticles = mockArticles
        let expectation = self.expectation(description: "Fetch Articles")
        viewModel.fetchArticles { success in
            XCTAssertTrue(success)
            XCTAssertEqual(self.viewModel.articles.count, 1)
            XCTAssertEqual(self.viewModel.articles.first?.title, "Title1")
            expectation.fulfill()
        }
        
        waitForExpectations(timeout: 2, handler: nil)
    }
    
    func testFetchArticlesFailure() async {
        mockRepository.mockArticles = nil
        
        let expectation = self.expectation(description: "Fetch Articles Failure")
        await viewModel.fetchArticles { success in
            XCTAssertFalse(success)
            XCTAssertEqual(self.viewModel.articles.count, 0)
            XCTAssertNil(self.viewModel.articles.first)
            expectation.fulfill()
        }
        await waitForExpectations(timeout: 2, handler: nil)
    }
}
